async function sendMessage() {
  const userInput = document.getElementById('userInput').value;
  if (!userInput) return;

  const messages = document.getElementById('messages');
  const userMessage = document.createElement('li');
  userMessage.classList.add('message', 'user');
  userMessage.innerHTML = `<p>${userInput}</p>`;
  messages.appendChild(userMessage);

  document.getElementById('userInput').value = '';

  const botMessage = document.createElement('li');
  botMessage.classList.add('message', 'bot');
  botMessage.innerHTML = `<p>Typing...</p>`;
  messages.appendChild(botMessage);

  try {
    const response = await fetch('/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message: userInput })
    });

    const data = await response.json();
    botMessage.innerHTML = `<p>${data.reply}</p>`;
  } catch (error) {
    botMessage.innerHTML = `<p>Error</p>`;
  }

  messages.scrollTop = messages.scrollHeight;
}
